# KPSS Tarih Öğrenme Merkezi — Android Uygulaması

Bu klasör, HTML dosyanı gerçek bir Android uygulamasına (APK) dönüştürmek için
gereken **tam Capacitor projesidir**. Not: Bu ortamda Android SDK/Gradle ve
internet erişimim olmadığı için APK'yı burada derleyemedim — ama aşağıdaki
yöntemlerden biriyle **kendi bilgisayarında ücretsiz ve kolayca** APK'yı
alabilirsin.

## Neler hazır?

- ✅ HTML/CSS/JS yapın `www/index.html` içine olduğu gibi kopyalandı (tasarım korunuyor)
- ✅ Açılış ekranı: "📚 KPSS Tarih Öğrenme Merkezi — Memur Yusuf, Kazım ve Burak için" yazısıyla, 1.6 saniye gösterilip kayboluyor
- ✅ Offline çalışma: dosya zaten tamamen kendi kendine yeterli (dış bağlantı yok), olduğu gibi offline çalışır
- ✅ Android geri tuşu: önce sayfa içi geri gitmeyi dener, sonra "çıkmak için tekrar bas" uyarısı verir
- ✅ Ekran yönü: dikey (portrait) kilitli
- ✅ Veri saklama: tarayıcı `localStorage`'ı Android WebView içinde otomatik kalıcıdır (uygulama kapansa da veriler telefonda kalır)
- ✅ Basit kitap temalı uygulama ikonu (`resources/icon.png`) — istersen kendi PNG'inle değiştirebilirsin
- ✅ GitHub Actions ile **otomatik APK derleme** iş akışı hazır

## YÖNTEM 1 — En kolay: GitHub Actions (Android Studio kurmadan)

1. [github.com](https://github.com) üzerinde ücretsiz bir hesap aç (varsa atla).
2. Yeni bir **boş** repo oluştur (örn. `kpss-tarih-app`).
3. Bu klasördeki (`kpss-tarih-app/`) tüm dosyaları o repoya yükle (GitHub web
   arayüzünden "Add file → Upload files" ile sürükle-bırak yapabilirsin, ya da
   `git push` kullan).
4. Yükleme bitince GitHub otomatik olarak "Actions" sekmesinde derlemeyi
   başlatır (birkaç dakika sürer).
5. Derleme bitince Actions sekmesindeki ilgili çalıştırmanın altında
   **"kpss-tarih-app-debug-apk"** adlı dosyayı indir — bu senin APK'n.
6. Bu `.apk` dosyasını telefonuna aktarıp kurabilirsin (Ayarlar → Bilinmeyen
   kaynaklardan yükleme izni gerekebilir).

## YÖNTEM 2 — Kendi bilgisayarında (Android Studio ile)

Gereksinimler: [Node.js](https://nodejs.org) ve [Android Studio](https://developer.android.com/studio)

```bash
cd kpss-tarih-app
npm install
npx cap add android
npx @capacitor/assets generate --android
npx cap sync android
npx cap open android
```

Android Studio açıldığında sağ üstten ▶️ (Run) butonuna basman ya da
üst menüden **Build → Build Bundle(s)/APK(s) → Build APK(s)** seçmen yeterli.
Derlenen APK şurada oluşur:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Uygulama adını / paket ID'sini değiştirmek istersen

`capacitor.config.json` içindeki `"appId"` ve `"appName"` alanlarını
düzenleyip yukarıdaki adımları tekrar çalıştırman yeterli.

## İkonu değiştirmek istersen

`resources/icon.png` dosyasının üzerine kendi 1024x1024 PNG ikonunu koy,
sonra `npx @capacitor/assets generate --android` komutunu tekrar çalıştır.

## Açılış ekranı yazısını değiştirmek istersen

`www/index.html` dosyasında `<div class="dedication">Memur Yusuf, Kazım ve
Burak için</div>` satırını bulup metni değiştirebilirsin — kod tarafında
başka bir şeye dokunmana gerek yok.

## Play Store için yayınlanabilir (release) APK/AAB

Debug APK test için yeterlidir ama Play Store'a yüklemek istersen imzalı
(signed) bir "release" derlemesi gerekir — bunun için Android Studio'da
**Build → Generate Signed Bundle/APK** yolunu izleyip kendi imza anahtarını
(keystore) oluşturman gerekir. İstersen bu adımda da sana rehberlik edebilirim.
